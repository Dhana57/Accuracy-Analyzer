const cv = n => 'rgb(' + getComputedStyle(document.documentElement).getPropertyValue('--' + n).trim().replace(/ /g, ',') + ')';
const tone = s => cv(s >= 80 ? 'good' : s >= 60 ? 'warn' : 'bad');

const { useState, useEffect, useRef, useCallback } = React;

const CODE = ['.py','.js','.jsx','.ts','.tsx','.java','.html','.css','.sql','.cpp','.c','.go'];
const ALLOWED = ['.zip','.csv', ...CODE];
const SKIP = ['node_modules/','.git/','venv/','__pycache__/','dist/','build/'];
const extOf = n => { const i = n.lastIndexOf('.'); return i < 0 ? '' : n.slice(i).toLowerCase(); };

function parseCSV(text) {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
    else if (c !== '\r') cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim()));
}

const SEV = { high: 0, medium: 1, low: 2 };
const mk = (severity, file, line, rule, message, fix) => ({ severity, file, line, rule, message, fix });
const lineOf = (txt, idx) => txt.slice(0, idx).split('\n').length;

function analyzeModel(text) {
  const rows = parseCSV(text);
  if (rows.length < 2) throw new Error('The CSV is empty.');
  const head = rows[0].map(h => h.trim().toLowerCase());
  const a = head.indexOf('actual'), p = head.indexOf('predicted');
  if (a < 0 || p < 0) throw new Error("The CSV needs columns named 'actual' and 'predicted'.");
  const issues = [], pairs = [];
  rows.slice(1).forEach((r, k) => {
    const row = k + 2;
    if (r.length !== head.length) return issues.push(mk('high', 'CSV', row, 'data', `This row has ${r.length} columns but the header has ${head.length}.`, 'Fix the row (look for stray commas, or wrap text in quotes).'));
    const x = (r[a] || '').trim(), y = (r[p] || '').trim();
    if (!x || !y) return issues.push(mk('high', 'CSV', row, 'data', `The ${!x ? 'actual' : 'predicted'} value is empty.`, 'Fill in the value or delete the row.'));
    pairs.push([x, y]);
  });
  const skipped = rows.length - 1 - pairs.length;
  if (!pairs.length) throw new Error('No usable rows: every row was malformed or had an empty value.');
  const labels = [...new Set(pairs.flat())].sort();
  const groups = {};
  labels.forEach(l => (groups[l.toLowerCase()] = groups[l.toLowerCase()] || []).push(l));
  Object.values(groups).filter(g => g.length > 1).forEach(g => issues.push(mk('medium', 'CSV', 0, 'data', `Labels ${g.map(x => "'" + x + "'").join(' and ')} differ only by letter case, so they count as different classes.`, 'Standardise label spelling before scoring.')));
  const actualSet = new Set(pairs.map(x => x[0]));
  const unseen = [...new Set(pairs.map(x => x[1]))].filter(l => !actualSet.has(l));
  if (unseen.length) issues.push(mk('medium', 'CSV', 0, 'data', `The model predicts labels that never appear in the actual column: ${unseen.slice(0, 5).join(', ')}.`, 'Check the label mapping between the model output and the ground truth.'));
  const idx = Object.fromEntries(labels.map((l, i) => [l, i]));
  const cm = labels.map(() => labels.map(() => 0));
  pairs.forEach(([x, y]) => cm[idx[x]][idx[y]]++);
  const n = pairs.length, correct = pairs.filter(([x, y]) => x === y).length;
  const per = labels.map((l, i) => {
    const tp = cm[i][i];
    const fp = cm.reduce((s, r, k) => k === i ? s : s + r[i], 0);
    const fn = cm[i].reduce((s, v, k) => k === i ? s : s + v, 0);
    const pr = tp + fp ? tp / (tp + fp) : 0, rc = tp + fn ? tp / (tp + fn) : 0;
    const f1 = pr + rc ? 2 * pr * rc / (pr + rc) : 0;
    return { label: l, precision: +pr.toFixed(3), recall: +rc.toFixed(3), f1: +f1.toFixed(3), support: tp + fn };
  });
  const acc = correct / n, macro = per.reduce((s, c) => s + c.f1, 0) / per.length;
  if (new Set(pairs.map(x => x[1])).size === 1 && labels.length > 1) issues.push(mk('high', 'Model', 0, 'model', 'The model predicts a single class for every row, so it has learned nothing useful.', 'Check training data, the label column, and that the right model file is being evaluated.'));
  const weak = per.filter(c => c.support && (c.recall < 0.7 || c.precision < 0.7));
  weak.forEach(c => issues.push(mk(c.recall < 0.7 ? 'high' : 'medium', 'Model', 0, 'weak-class', `Class '${c.label}' has precision ${Math.round(c.precision * 100)}% and recall ${Math.round(c.recall * 100)}%.`, c.recall < 0.7 ? 'Add more labelled examples of this class or give it a higher class weight.' : 'Review its false positives and tighten the features or decision threshold.')));
  const conf = []; cm.forEach((r, i) => r.forEach((v, j) => { if (i !== j && v) conf.push([i, j, v]); })); conf.sort((x, y) => y[2] - x[2]);
  conf.slice(0, 3).forEach(([i, j, v]) => issues.push(mk(v / n > 0.05 ? 'medium' : 'low', 'Model', 0, 'confusion', `'${labels[i]}' is predicted as '${labels[j]}' ${v} time(s), one of the most common mistakes.`, `Read those examples and add features or training data that separate '${labels[i]}' from '${labels[j]}'.`)));
  const sup = per.map(c => c.support);
  if (Math.max(...sup) > 5 * Math.max(Math.min(...sup), 1)) issues.push(mk('medium', 'Model', 0, 'imbalance', 'Classes are imbalanced (the largest is over 5x the smallest), so accuracy can look better than it is.', 'Use stratified splits, resampling or class weights, and judge by F1.'));
  if (n < 200) issues.push(mk('medium', 'CSV', 0, 'small-sample', `Only ${n} usable rows, so results will be noisy.`, 'Evaluate on at least a few hundred rows per run.'));
  if (acc - macro > 0.1) issues.push(mk('high', 'Model', 0, 'majority-bias', 'Accuracy is much higher than macro-F1: the model favours the biggest classes.', 'Report macro-F1, and rebalance the training data.'));
  issues.sort((x, y) => SEV[x.severity] - SEV[y.severity]);
  const dataErr = issues.filter(i => i.rule === 'data' && i.severity === 'high').length + skipped * 0;
  const plan = [];
  if (issues.some(i => i.rule === 'data')) plan.push({ title: 'Fix the data problems first', why: `${issues.filter(i => i.rule === 'data').length} data issue(s) were found${skipped ? ` and ${skipped} row(s) were left out of the score` : ''}.`, steps: ['Open the CSV and correct each row listed under Issues.', 'Make label spelling and case consistent in both columns.', 'Upload the cleaned file again.'] });
  if (weak.length) plan.push({ title: 'Improve the weakest classes', why: `Weak classes: ${weak.map(c => c.label).join(', ')}.`, steps: ['Collect or label more examples for these classes.', 'Use class weights or oversampling during training.', 'Tune the decision threshold for each weak class and re-test.'] });
  if (conf.length) plan.push({ title: 'Study the most common mistakes', why: `The top confusion is '${labels[conf[0][0]]}' predicted as '${labels[conf[0][1]]}' (${conf[0][2]} times).`, steps: ['Export the rows behind the top 3 confusions and read them.', 'Decide whether it is a labelling error or a missing feature.', 'Fix the labels or add features, then retrain.'] });
  plan.push({ title: 'Validate it properly', why: n < 200 ? `Only ${n} rows were tested.` : 'A single test run can hide overfitting.', steps: ['Keep a hold-out test set the model never trains on.', 'Use k-fold cross-validation (k = 5) to see how stable the score is.', 'Track macro-F1 over time with this tool, not just accuracy.'] });
  const verdict = macro >= 0.8 ? 'Accurate' : macro >= 0.6 ? 'Fair: room to improve' : 'Weak: needs work';
  return { kind: 'model', score: +(macro * 100).toFixed(1), accuracy: +(acc * 100).toFixed(1), rows: n, labels, confusion: cm, per_class: per, issues: issues.slice(0, 300), action_plan: plan, verdict };
}

// Blank out strings and comments but keep offsets and newlines, so braces can be matched safely.
const blank = m => m.replace(/[^\n]/g, ' ');
const stripNoise = t => t.replace(/(["'`])(?:\\.|(?!\1)[^\\\n])*\1/g, blank).replace(/\/\*[\s\S]*?\*\//g, blank).replace(/\/\/.*$/gm, blank);
const BR_PY = /\b(if|elif|for|while|except|and|or|case)\b/g;
const BR_C = /\b(if|for|while|case|catch)\b|&&|\|\||\?/g;
const NOT_FN = new Set(['if', 'for', 'while', 'switch', 'catch', 'return', 'else', 'with', 'function']);

function pyFunctions(lines) {
  const out = [];
  lines.forEach((l, i) => {
    const m = l.match(/^(\s*)(?:async\s+)?def\s+(\w+)/);
    if (!m) return;
    const ind = m[1].length; let end = i;
    for (let j = i + 1; j < lines.length; j++) {
      if (!lines[j].trim()) continue;
      if (lines[j].match(/^\s*/)[0].length <= ind) break;
      end = j;
    }
    const body = lines.slice(i + 1, end + 1), first = body.find(x => x.trim());
    out.push({ name: m[2], length: end - i + 1, cx: 1 + (body.join('\n').match(BR_PY) || []).length, doc: !!first && /^\s*[rRbBuU]?("""|''')/.test(first) });
  });
  return out;
}

function braceFunctions(orig) {
  const s = stripNoise(orig), out = [];
  const re = /(?:function\s*\*?\s*(\w*)\s*\([^)]*\)|(\w+)\s*[=:]\s*(?:async\s*)?\([^)]*\)\s*=>|\b(\w+)\s*\([^)]*\)(?:\s*(?:throws\s+[\w.,\s]+|:\s*[\w<>\[\]|. ]+))?)\s*\{/g;
  let m;
  while ((m = re.exec(s))) {
    const name = m[1] || m[2] || m[3] || 'anonymous';
    if (NOT_FN.has(name)) continue;
    let depth = 0, k = re.lastIndex - 1;
    for (; k < s.length; k++) { if (s[k] === '{') depth++; else if (s[k] === '}' && --depth === 0) break; }
    const body = s.slice(m.index, k + 1);
    const before = orig.slice(0, m.index).trimEnd();
    const length = body.split('\n').length;
    out.push({ name, length, cx: 1 + (body.match(BR_C) || []).length, doc: before.endsWith('*/') || /(^|\n)\s*\/\/[^\n]*$/.test(before) });
  }
  return out;
}

const pyStrip = t => t.replace(/("""|''')[\s\S]*?\1/g, m => '"' + blank(m.slice(1))).replace(/(["'])(?:\\.|(?!\1)[^\\\n])*\1/g, blank).replace(/#.*$/gm, blank);
const cssStrip = t => t.replace(/(["'])(?:\\.|(?!\1)[^\\\n])*\1/g, blank).replace(/\/\*[\s\S]*?\*\//g, blank);
const jsStrip = t => stripNoise(t).replace(/(^|[=(:,\[!&|?{};]\s*)\/(?![*\/])(?:\\.|\[(?:\\.|[^\]\\\n])*\]|[^\/\\\n\[])+\/[gimsuy]*/gm, (m, p) => p + blank(m.slice(p.length)));

function checkBrackets(file, s, out) {
  const pairs = { ')': '(', ']': '[', '}': '{' }, stack = []; let line = 1;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '\n') line++;
    else if ('([{'.includes(c)) stack.push([c, line]);
    else if (pairs[c]) {
      const top = stack.pop();
      if (!top || top[0] !== pairs[c]) { out.push(mk('high', file, line, 'syntax', `Unexpected '${c}'${top ? ` (the '${top[0]}' opened on line ${top[1]} is not closed)` : ' with nothing open'}.`, 'Add the missing bracket or remove the extra one.')); return true; }
    }
  }
  if (stack.length) { const [c, l] = stack[stack.length - 1]; out.push(mk('high', file, l, 'syntax', `'${c}' opened here is never closed.`, 'Add the matching closing bracket.')); return true; }
  return false;
}

function checkPython(file, txt, out) {
  const lines = pyStrip(txt).split('\n'), raw = txt.split('\n');
  let depth = 0, prev = null, cont = false;
  lines.forEach((l, i) => {
    const n = i + 1, startDepth = depth;
    for (const c of l) { if ('([{'.includes(c)) depth++; else if (')]}'.includes(c)) depth = Math.max(0, depth - 1); }
    if (!l.trim() || !raw[i].trim()) return;
    if (startDepth > 0) return;
    if (cont) { cont = /\\\s*$/.test(l); return; }
    const ws = l.match(/^[ \t]*/)[0], t = l.trim();
    if (ws.includes('\t') && ws.includes(' ')) out.push(mk('high', file, n, 'indentation', 'Tabs and spaces are mixed in this line’s indentation.', 'Use 4 spaces everywhere (set your editor to insert spaces).'));
    const indent = ws.replace(/\t/g, '    ').length;
    if (prev) {
      if (prev.block && indent <= prev.indent) out.push(mk('high', file, n, 'syntax', `Expected an indented block after line ${prev.n}.`, 'Indent the body, or write pass as a placeholder.'));
      else if (!prev.block && indent > prev.indent) out.push(mk('high', file, n, 'syntax', 'Unexpected indent.', 'Align this line with the previous statement.'));
    }
    const isBlock = /^(def|class|if|elif|else|for|while|try|except|finally|with|async\s+def|async\s+for|async\s+with)\b/.test(t);
    if (isBlock && !t.includes(':') && depth === 0 && !/\\$/.test(t)) out.push(mk('high', file, n, 'syntax', 'This statement is missing the colon (:) at its end.', 'Add ":" at the end of the line.'));
    prev = { indent, n, block: isBlock && /:$/.test(t) };
    cont = /\\\s*$/.test(l);
  });
}

const PY_RULES = [
  [/\bexcept\s*:/g, 'medium', 'bare-except', 'A bare "except:" hides real errors.', 'Catch specific exceptions, such as except ValueError as e, and log them.'],
  [/def\s+\w+\s*\([^)]*=\s*(\[\]|\{\}|set\(\))/g, 'high', 'mutable-default', 'A mutable default argument is shared between calls and causes hard-to-find bugs.', 'Default to None and create the list or dict inside the function.'],
  [/[=!]=\s*None\b/g, 'low', 'none-compare', 'None should be compared with "is" or "is not".', 'Replace == None with is None.'],
  [/\b(eval|exec)\s*\(/g, 'high', 'eval', 'eval/exec can run attacker-controlled code.', 'Use ast.literal_eval or explicit parsing instead.'],
  [/shell\s*=\s*True/g, 'high', 'shell-true', 'shell=True allows command injection.', 'Pass the command as a list and drop shell=True.'],
  [/\.run\([^)]*debug\s*=\s*True/g, 'medium', 'debug-on', 'Debug mode is on, which exposes an interactive console.', 'Turn debug off outside local development.'],
  [/except[^\n:]*:[ \t]*\n\s*pass\b/g, 'medium', 'swallowed-error', 'An error is caught and silently ignored.', 'Log the error or handle it explicitly.'],
  [/from\s+[\w.]+\s+import\s+\*/g, 'low', 'star-import', 'Star imports hide where names come from.', 'Import only the names you use.'],
];
const JS_RULES = [
  [/\beval\s*\(/g, 'high', 'eval', 'eval can run attacker-controlled code.', 'Parse data with JSON.parse or explicit logic instead.'],
  [/\.innerHTML\s*=/g, 'medium', 'innerhtml', 'Assigning innerHTML can allow cross-site scripting (XSS).', 'Use textContent, or sanitize the HTML first.'],
  [/\bdocument\.write\s*\(/g, 'medium', 'document-write', 'document.write is unsafe and blocks page loading.', 'Build elements with DOM methods instead.'],
  [/\bdebugger\b/g, 'medium', 'debugger', 'A debugger statement is left in the code.', 'Remove it before release.'],
  [/catch\s*(\([^)]*\))?\s*\{\s*\}/g, 'medium', 'empty-catch', 'An empty catch block hides errors.', 'Log or handle the error.'],
  [/(?<![=!<>])==(?!=)|!=(?!=)/g, 'low', 'loose-equality', 'Loose equality (==) can give surprising results.', 'Use === and !==.'],
  [/\bconsole\.log\s*\(/g, 'low', 'console-log', 'console.log calls are left in the code.', 'Remove them or use a proper logger.'],
];
const ALL_RULES = [
  [/(api[_-]?key|secret|passw(or)?d|token)\s*[:=]\s*["'](?!your|change|xxx|<|\$\{|example|test)[^"'\s]{8,}["']/gi, 'high', 'secret', 'A password, token or API key looks hard-coded in the source.', 'Move it to an environment variable, and rotate the exposed key.'],
  [/AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC )?PRIVATE KEY-----/g, 'high', 'secret', 'A cloud key or private key is stored in the source.', 'Remove it, rotate it, and load it from a secrets manager.'],
];
const SECURITY_RULES = new Set(['secret', 'eval', 'shell-true', 'debug-on', 'innerhtml', 'document-write', 'sql-injection', 'env-file']);

function groupIssues(file, rules, s, out) {
  rules.forEach(([re, sev, rule, msg, fix]) => {
    const ms = [...s.matchAll(re)];
    if (ms.length) out.push(mk(sev, file, lineOf(s, ms[0].index), rule, ms.length > 1 ? `${msg} (${ms.length} places, first one shown)` : msg, fix));
  });
}

function checkOther(file, ext, txt, out) {
  if (ext === '.html') {
    ['div', 'ul', 'ol', 'table', 'section', 'form', 'span', 'p'].forEach(tag => {
      const o = (txt.match(new RegExp('<' + tag + '[\\s>]', 'gi')) || []).length, c = (txt.match(new RegExp('</' + tag + '>', 'gi')) || []).length;
      if (o !== c) out.push(mk('medium', file, 0, 'unclosed-tag', `<${tag}> is opened ${o} time(s) but closed ${c} time(s).`, `Add or remove a </${tag}> so every opening tag is closed.`));
    });
    const img = [...txt.matchAll(/<img\b(?![^>]*\balt=)[^>]*>/gi)];
    if (img.length) out.push(mk('low', file, lineOf(txt, img[0].index), 'img-alt', `${img.length} image(s) have no alt text.`, 'Add alt="..." so screen readers can describe them.'));
  }
  if (ext === '.sql') {
    const bad = [...txt.matchAll(/\b(DELETE\s+FROM\s+\w+|UPDATE\s+\w+\s+SET\s[^;]*?)\s*;/gi)].filter(m => !/\bWHERE\b/i.test(m[0]));
    if (bad.length) out.push(mk('high', file, lineOf(txt, bad[0].index), 'sql-no-where', 'A DELETE or UPDATE has no WHERE clause and will change every row.', 'Add a WHERE clause (and test on a copy first).'));
  }
  const li = txt.split('\n').findIndex(l => /(execute|query|exec)\w*\s*\(/i.test(l) && /\b(SELECT|INSERT|UPDATE|DELETE)\b/i.test(l) && /\$\{|["']\s*\+|\+\s*["']|\bf["']|\.format\(|["']\s*%\s*[\w(]/.test(l));
  if (li >= 0) out.push(mk('high', file, li + 1, 'sql-injection', 'A SQL query is built by joining strings, which allows SQL injection.', 'Use parameterized queries (placeholders) instead.'));
}

function analyzeCode(files, names = [], extra = {}, isProject = false) {
  const m = { files: 0, loc: 0, comments: 0, todos: 0, test_files: 0, functions: 0, long_functions: 0, no_docstring: 0, complex_functions: 0, syntax_errors: 0 };
  const byExt = {}, hot = [], issues = []; const BRACE = ['.js', '.jsx', '.ts', '.tsx', '.java', '.c', '.cpp', '.go'];
  for (const [name, txt] of Object.entries(files)) {
    const ext = extOf(name), lines = txt.split(/\r?\n/).filter(l => l.trim());
    m.files++; m.loc += lines.length; byExt[ext] = (byExt[ext] || 0) + lines.length;
    m.comments += lines.filter(l => /^\s*(#|\/\/|\/\*|\*)/.test(l)).length;
    m.todos += (txt.match(/TODO|FIXME/g) || []).length;
    const low = name.toLowerCase();
    if (low.split('/').pop().includes('test') || /(^|\/)(tests?|__tests__)\//.test(low)) m.test_files++;
    let fns = [];
    if (ext === '.py') {
      const s = pyStrip(txt); fns = pyFunctions(txt.split(/\r?\n/));
      checkBrackets(name, s, issues); checkPython(name, txt, issues);
      groupIssues(name, PY_RULES, s, issues);
    } else if (BRACE.includes(ext)) {
      fns = braceFunctions(txt);
      const s = ['.js', '.jsx', '.ts', '.tsx'].includes(ext) ? jsStrip(txt) : stripNoise(txt);
      checkBrackets(name, s, issues);
      if (['.js', '.jsx', '.ts', '.tsx'].includes(ext)) groupIssues(name, JS_RULES, s, issues);
    } else if (ext === '.css') checkBrackets(name, cssStrip(txt), issues);
    checkOther(name, ext, txt, issues); groupIssues(name, ALL_RULES, txt, issues);
    fns.forEach(f => {
      m.functions++;
      if (f.length > 50) m.long_functions++;
      if (!f.doc) m.no_docstring++;
      if (f.cx > 10) { m.complex_functions++; hot.push({ file: name, function: f.name, complexity: f.cx }); }
    });
  }
  if (!m.files) throw new Error('No source files found. Supported: ' + CODE.join(' '));
  const has = re => names.some(n => re.test(n));
  const setup = { 'a README': has(/(^|\/)readme(\.\w+)?$/i), 'a dependency file (requirements.txt or package.json)': has(/(^|\/)(requirements\.txt|package\.json|pyproject\.toml|pom\.xml|build\.gradle|go\.mod|Pipfile)$/i), 'a .gitignore': has(/(^|\/)\.gitignore$/), 'automated checks (CI)': has(/(^|\/)(\.github\/workflows\/|\.gitlab-ci\.yml|Jenkinsfile|azure-pipelines\.yml)/) };
  if (has(/(^|\/)\.env$/)) issues.push(mk('high', '.env', 0, 'env-file', 'A .env file is inside the project and usually holds secrets.', 'Remove it from the project, add it to .gitignore, and rotate the keys it contains.'));
  const req = Object.entries(extra).find(([k]) => /requirements\.txt$/i.test(k));
  if (req) { const loose = req[1].split('\n').map(x => x.trim()).filter(x => x && !x.startsWith('#') && !x.startsWith('-') && !x.includes('==')); if (loose.length) issues.push(mk('medium', req[0], 0, 'unpinned', `${loose.length} dependenc${loose.length > 1 ? 'ies are' : 'y is'} not pinned to a version (for example ${loose[0]}).`, 'Pin exact versions (package==1.2.3) so builds are repeatable.')); }
  issues.sort((x, y) => SEV[x.severity] - SEV[y.severity]);
  const errs = issues.filter(i => i.rule === 'syntax' || i.rule === 'indentation').length; m.syntax_errors = errs;
  const sec = issues.filter(i => SECURITY_RULES.has(i.rule)), secHigh = sec.filter(i => i.severity === 'high').length;
  const src = Math.max(m.files - m.test_files, 1), fn = Math.max(m.functions, 1);
  const dims = {
    Testing: Math.min(1, (m.test_files / src) / 0.3),
    Documentation: Math.min(1, (m.comments / Math.max(m.loc, 1)) / 0.1) * 0.5 + (m.functions ? 1 - m.no_docstring / fn : 0.5) * 0.5,
    Complexity: 1 - m.complex_functions / fn,
    Maintainability: 1 - m.long_functions / fn - Math.min(m.todos, 50) / 100,
    Correctness: 1 - Math.min(1, errs * 0.25),
    Security: 1 - Math.min(1, secHigh * 0.3 + (sec.length - secHigh) * 0.1),
  };
  const w = { Testing: .2, Documentation: .1, Complexity: .15, Maintainability: .1, Correctness: .2, Security: .15 };
  if (isProject) { dims['Project setup'] = Object.values(setup).filter(Boolean).length / 4; w['Project setup'] = .1; }
  Object.keys(dims).forEach(k => dims[k] = +(Math.min(1, Math.max(0, dims[k])) * 100).toFixed(1));
  const wsum = Object.values(w).reduce((a, b) => a + b, 0);
  let score = +(Object.keys(dims).reduce((s, k) => s + dims[k] * w[k], 0) / wsum).toFixed(1);
  if (errs) score = Math.min(score, 69);
  const verdict = errs ? 'Has errors that stop it running' : secHigh ? 'Runs, but has serious security risks' : score >= 80 ? 'Healthy' : score >= 60 ? 'Needs work' : 'At risk';
  const plan = [], first = issues.find(i => i.rule === 'syntax' || i.rule === 'indentation');
  if (errs) plan.push({ title: 'Fix the errors that stop it running', why: `${errs} syntax or indentation error(s) found, starting at ${first.file}:${first.line}.`, steps: ['Open each file and line listed under Issues and apply the suggested fix.', 'Run the project (python file.py, npm run build) after each fix to confirm.', 'Add a linter (ruff for Python, ESLint for JavaScript) so errors show while you type.'] });
  if (sec.length) plan.push({ title: 'Remove secrets and unsafe code', why: `${sec.length} security issue(s) found${secHigh ? `, ${secHigh} of them serious` : ''}.`, steps: ['Move keys and passwords into environment variables and never commit them.', 'Rotate any key that was ever in the code.', 'Replace eval, shell=True and string-built SQL with safe alternatives.'] });
  if (dims.Testing < 60) plan.push({ title: 'Add automated tests', why: `Only ${m.test_files} test file(s) for ${src} source file(s).`, steps: ['Write one test each for the 3 most important functions (pytest or Jest).', 'Cover normal input, empty input and invalid input.', 'Aim for about 70% coverage of core logic, and run the tests before every commit.'] });
  if (m.complex_functions || m.long_functions) plan.push({ title: 'Simplify large functions', why: `${m.complex_functions} function(s) are very complex and ${m.long_functions} are over 50 lines.`, steps: ['Split long functions into small, well-named helpers.', 'Replace deep if/else nesting with early returns.', 'Re-run this analysis and watch Complexity rise.'] });
  const missing = Object.entries(setup).filter(([, v]) => !v).map(([k]) => k);
  if (isProject && missing.length) plan.push({ title: 'Complete the project setup', why: `Missing: ${missing.join(', ')}.`, steps: ['Add a README that says what the project does and how to install and run it.', 'List dependencies with exact versions so anyone can reproduce your setup.', 'Add CI (for example GitHub Actions) that runs the linter and tests on every push.'] });
  if (dims.Documentation < 60) plan.push({ title: 'Document the code', why: `${m.no_docstring} of ${m.functions} functions have no docstring or comment.`, steps: ['Describe inputs, outputs and edge cases for each public function.', 'Turn each TODO or FIXME into a tracked issue.'] });
  plan.push({ title: 'Re-check after every change', why: 'A score only means something as a trend.', steps: ['Upload the project again after each fix.', 'Watch Score history go up.', 'You are in good shape when there are no high issues and Testing is above 70.'] });
  const loc_by_ext = Object.fromEntries(Object.entries(byExt).sort((a, b) => b[1] - a[1]).slice(0, 8));
  return { kind: 'code', score, metrics: m, dimensions: dims, loc_by_ext, hotspots: hot.sort((a, b) => b.complexity - a.complexity).slice(0, 10), issues: issues.slice(0, 300), action_plan: plan, verdict };
}

async function readZip(file) {
  const z = await JSZip.loadAsync(file), files = {}, names = [], extra = {}; let total = 0, count = 0;
  for (const [name, entry] of Object.entries(z.files)) {
    const n = name.replace(/\\/g, '/');
    if (entry.dir || SKIP.some(s => n.includes(s))) continue;
    if (names.length < 5000) names.push(n);
    if (/(^|\/)requirements\.txt$/i.test(n)) extra[n] = await entry.async('string');
    if (!CODE.includes(extOf(n))) continue;
    if (++count > 3000) throw new Error('The zip has more than 3000 source files.');
    const txt = await entry.async('string');
    total += txt.length;
    if (total > 150e6) throw new Error('The zip is too large when unpacked.');
    files[n] = txt;
  }
  return { files, names, extra };
}

function useChart(cfg, deps) {
  const ref = useRef(null);
  useEffect(() => {
    const c = new Chart(ref.current, cfg());
    return () => c.destroy();
  }, deps);
  return ref;
}

function Panel({ title, children, className = '' }) {
  return (
    <section className={`bg-panel border border-line rounded-lg p-5 ${className}`}>
      <h2 className="font-display text-lg mb-3">{title}</h2>
      {children}
    </section>
  );
}

function Score({ score }) {
  const ref = useChart(() => ({
    type: 'doughnut',
    data: { datasets: [{ data: [score, 100 - score], backgroundColor: [tone(score), 'rgba(128,140,145,.25)'], borderWidth: 0 }] },
    options: { cutout: '78%', plugins: { tooltip: { enabled: false } }, events: [] }
  }), [score]);
  return (
    <div className="relative w-44 h-44 mx-auto">
      <canvas ref={ref} />
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="font-display text-4xl num" style={{ color: tone(score) }}>{score}</div>
          <div className="text-xs text-ink/60">out of 100</div>
        </div>
      </div>
    </div>
  );
}

function Bars({ labels, data, label, horizontal }) {
  const ref = useChart(() => ({
    type: 'bar',
    data: { labels, datasets: [{ label, data, backgroundColor: data.map(v => horizontal ? tone(v) : cv('teal')), borderRadius: 3 }] },
    options: { indexAxis: horizontal ? 'y' : 'x', plugins: { legend: { display: false } },
      scales: horizontal ? { x: { min: 0, max: 100 } } : {} }
  }), [JSON.stringify(data)]);
  return <canvas ref={ref} height="170" />;
}

function Radar({ dims }) {
  const ref = useChart(() => ({
    type: 'radar',
    data: { labels: Object.keys(dims), datasets: [{ data: Object.values(dims), backgroundColor: 'rgba(42,143,160,.2)', borderColor: cv('teal'), pointBackgroundColor: cv('teal') }] },
    options: { plugins: { legend: { display: false } }, scales: { r: { min: 0, max: 100, ticks: { stepSize: 25 } } } }
  }), [JSON.stringify(dims)]);
  return <canvas ref={ref} height="200" />;
}

function Confusion({ labels, matrix }) {
  const max = Math.max(...matrix.flat(), 1);
  return (
    <div className="overflow-x-auto">
      <table className="text-sm num border-separate border-spacing-1">
        <thead><tr><th className="text-xs text-ink/60 font-normal text-left">actual \ predicted</th>
          {labels.map(l => <th key={l} className="px-2 font-medium">{l}</th>)}</tr></thead>
        <tbody>{matrix.map((row, i) => (
          <tr key={i}><th className="pr-3 text-left font-medium">{labels[i]}</th>
            {row.map((v, j) => (
              <td key={j} title={`${labels[i]} predicted as ${labels[j]}`}
                  className="w-14 h-10 text-center rounded"
                  style={{ background: i === j ? `rgba(46,125,91,${.12 + .8 * v / max})` : `rgba(178,58,72,${v ? .1 + .8 * v / max : 0})`,
                           color: v / max > .55 ? '#fff' : 'rgb(var(--ink))' }}>{v}</td>))}
          </tr>))}</tbody>
      </table>
    </div>
  );
}

function Recs({ items }) {
  const color = { high: 'bg-bad', medium: 'bg-warn', low: 'bg-good' };
  return (
    <ul className="space-y-2">
      {items.map(([sev, text], i) => (
        <li key={i} className="flex gap-3 items-start">
          <span className={`${color[sev]} text-page text-xs rounded px-2 py-0.5 mt-0.5 shrink-0`}>{sev}</span>
          <span>{text}</span>
        </li>))}
    </ul>
  );
}

function Section({ id, title, intro, children }) {
  return (
    <section id={id} className="pb-16 scroll-mt-20">
      <h2 className="font-display text-3xl">{title}</h2>
      {intro && <p className="text-ink/70 mt-2 mb-6 max-w-2xl">{intro}</p>}
      {children}
    </section>
  );
}

const EX = {
  Python: ['import os', 'API_KEY = "sk_live_abc12345678"', '', 'def add(item, bucket=[]):', '    if item == None', '        return bucket', '    bucket.append(item)', '    return bucket', '', 'def load(q, cursor):', '    try:', '        cursor.execute("SELECT * FROM users WHERE id=" + q)', '    except:', '        pass'].join('\n'),
  JavaScript: ['function total(items) {', '  let sum = 0;', '  for (var i = 0; i <= items.length; i++) {', '    if (items[i].price == null) { console.log("skip") }', '    sum += items[i].price;', '  }', '  document.getElementById("out").innerHTML = sum;', '  return sum;', '}', '', 'const password = "hunter2hunter2";', 'if (total([]) {', '  debugger;', '}'].join('\n'),
};

function Playground() {
  const [lang, setLang] = useState('Python');
  const [code, setCode] = useState(EX.Python);
  let res = null;
  try { res = analyzeCode({ [lang === 'Python' ? 'snippet.py' : 'snippet.js']: code }); } catch (e) { res = null; }
  const issues = res ? res.issues : [];
  const n = s => issues.filter(i => i.severity === s).length;
  const pick = l => { setLang(l); setCode(EX[l]); };
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div>
        <div className="flex gap-2 mb-2">
          {['Python', 'JavaScript'].map(l => (
            <button key={l} onClick={() => pick(l)} aria-pressed={lang === l} className={'text-sm rounded-full border px-3 py-1 ' + (lang === l ? 'bg-teal text-page border-teal' : 'border-line hover:bg-mist')}>{l}</button>))}
          <button onClick={() => setCode(EX[lang])} className="ml-auto text-sm underline">Reset example</button>
        </div>
        <textarea value={code} onChange={e => setCode(e.target.value)} spellCheck={false} aria-label="Code to check" rows={16}
          className="w-full border border-line rounded-lg p-3 bg-panel text-sm leading-relaxed" style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }} />
      </div>
      <Panel title="Found as you type">
        <p className="text-sm text-ink/70 mb-3 num">{issues.length} issue(s): {n('high')} high, {n('medium')} medium, {n('low')} low. Edit the code and watch them change.</p>
        <Issues items={issues} />
      </Panel>
    </div>
  );
}

const CHECKS = {
  'Code errors': { items: ['Unclosed or unmatched ( [ { brackets, with the line number', 'Python statements missing a colon', 'Unexpected or missing indentation, and tabs mixed with spaces', 'HTML tags that are opened but never closed', 'SQL DELETE or UPDATE with no WHERE'], example: 'def total(items)\n    return sum(items)', says: 'Line 1: this statement is missing the colon (:) at its end.' },
  'Security': { items: ['Hard-coded passwords, tokens and private keys', 'eval, exec and shell=True', 'SQL built by joining strings', 'innerHTML and document.write', 'A .env file inside the project'], example: 'password = "hunter2hunter2"', says: 'A password, token or API key looks hard-coded in the source.' },
  'Bug patterns': { items: ['Mutable default arguments', 'Bare except and silently swallowed errors', '== instead of === in JavaScript', 'Leftover debugger and console.log', 'Very complex or very long functions'], example: 'def add(x, bucket=[]):', says: 'A mutable default argument is shared between calls and causes hard-to-find bugs.' },
  'Prediction data': { items: ['Rows with the wrong number of columns', 'Empty actual or predicted values', 'Labels that differ only by letter case', 'A model that predicts one class for everything', 'Weak classes and the most common mix-ups'], example: 'actual,predicted\ncat,Cat', says: "Labels 'Cat' and 'cat' differ only by letter case, so they count as different classes." },
  'Project setup': { items: ['README, dependency file and .gitignore', 'Automated checks (CI)', 'Unpinned dependency versions', 'Test files compared with source files'], example: 'flask\nrequests==2.31.0', says: '1 dependency is not pinned to a version (for example flask).' },
};

function Checks() {
  const [tab, setTab] = useState('Code errors');
  const c = CHECKS[tab];
  return (
    <div>
      <div role="tablist" className="flex flex-wrap gap-2 mb-5">
        {Object.keys(CHECKS).map(k => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={'rounded-md border px-4 py-1.5 text-sm ' + (tab === k ? 'bg-teal text-page border-teal' : 'border-line hover:bg-mist')}>{k}</button>))}
      </div>
      <div role="tabpanel" className="grid gap-6 md:grid-cols-2">
        <ul className="space-y-2 list-disc ml-5">{c.items.map(t => <li key={t}>{t}</li>)}</ul>
        <div>
          <pre className="bg-panel border border-line rounded-lg p-3 text-sm overflow-x-auto" style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>{c.example}</pre>
          <p className="mt-2 text-sm"><span className="bg-bad text-page text-xs rounded px-2 py-0.5 mr-2">flagged</span>{c.says}</p>
        </div>
      </div>
    </div>
  );
}

const DIMS = [['Testing', 20], ['Documentation', 10], ['Complexity', 15], ['Maintainability', 10], ['Correctness', 20], ['Security', 15], ['Project setup', 10]];

function ScoreLab() {
  const init = () => Object.fromEntries(DIMS.map(([k]) => [k, 60]));
  const [v, setV] = useState(init);
  const [err, setErr] = useState(false);
  const total = DIMS.reduce((s, [k, w]) => s + v[k] * w / 100, 0);
  const shown = err ? Math.min(total, 69) : total;
  const best = DIMS.map(([k, w]) => [k, (100 - v[k]) * w / 100]).sort((a, b) => b[1] - a[1])[0];
  const verdict = err ? 'Has errors that stop it running' : shown >= 80 ? 'Healthy' : shown >= 60 ? 'Needs work' : 'At risk';
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="md:col-span-2 space-y-3">
        {DIMS.map(([k, w]) => (
          <label key={k} className="block">
            <div className="flex justify-between text-sm"><span>{k} <span className="text-ink/60">(worth {w}%)</span></span><span className="num">{v[k]}</span></div>
            <input type="range" min="0" max="100" value={v[k]} onChange={e => setV({ ...v, [k]: +e.target.value })} className="w-full accent-teal" />
          </label>))}
        <div className="flex flex-wrap items-center gap-4 pt-2">
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={err} onChange={e => setErr(e.target.checked)} /> The project has a syntax error</label>
          <button onClick={() => { setV(init()); setErr(false); }} className="text-sm underline">Reset sliders</button>
        </div>
      </div>
      <Panel title="Projected score">
        <div className="text-center">
          <div className="font-display text-6xl num" style={{ color: tone(shown) }}>{shown.toFixed(1)}</div>
          <div className="font-medium mt-1" style={{ color: tone(shown) }}>{verdict}</div>
        </div>
        <p className="text-sm text-ink/70 mt-4">{err ? 'Fix the syntax error first: while one exists, the score cannot go above 69.' : 'Biggest opportunity: ' + best[0] + ' could add up to ' + best[1].toFixed(1) + ' points.'}</p>
      </Panel>
    </div>
  );
}

const FAQ = [
  ['Does it run my code?', 'No. It reads your files and looks for errors and risky patterns, so it is safe to use on any project. It can’t catch bugs that only appear when the code runs, so keep running your own tests too.'],
  ['Are my files uploaded anywhere?', 'No. Everything is analysed inside your browser tab. Your run history is stored only in this browser, and the Clear history button removes it.'],
  ['Why is my score capped at 69?', 'A project with a syntax error can’t run, so it shouldn’t be rated as good. Fix the errors and the cap disappears.'],
  ['Which languages are supported?', 'Python, JavaScript, TypeScript, Java, C, C++ and Go get the deepest checks. HTML, CSS and SQL get structure and safety checks. A CSV with actual and predicted columns is scored as model accuracy.'],
  ['What is the fastest way to raise my score?', 'Fix errors first, then remove exposed secrets, then add tests. The Scoring section above shows how much each area is worth.'],
];

function Faq() {
  return (
    <div className="max-w-3xl divide-y divide-line border-y border-line">
      {FAQ.map(([q, a]) => (
        <details key={q} className="py-3 group">
          <summary className="cursor-pointer font-medium list-none flex justify-between gap-4">{q}<span className="text-ink/60 group-open:rotate-45 transition-transform">+</span></summary>
          <p className="text-ink/70 mt-2">{a}</p>
        </details>))}
    </div>
  );
}

function Issues({ items }) {
  const [all, setAll] = useState(false), [sev, setSev] = useState('all'), [q, setQ] = useState('');
  if (!items.length) return <p className="text-ink/70">No errors or risky patterns found.</p>;
  const color = { high: 'bg-bad', medium: 'bg-warn', low: 'bg-good' };
  const count = s => items.filter(x => s === 'all' || x.severity === s).length;
  const list = items.filter(x => (sev === 'all' || x.severity === sev) && (x.file + ' ' + x.message + ' ' + x.rule).toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-3">
        {['all', 'high', 'medium', 'low'].map(s => (
          <button key={s} onClick={() => setSev(s)} aria-pressed={sev === s} className={'text-sm rounded-full border px-3 py-1 ' + (sev === s ? 'bg-teal text-page border-teal' : 'border-line hover:bg-mist')}>{s} ({count(s)})</button>))}
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search issues" aria-label="Search issues" className="ml-auto border border-line rounded-md px-3 py-1 text-sm bg-panel w-44" />
      </div>
      {list.length ? (
        <ul className="divide-y divide-line">
          {(all ? list : list.slice(0, 10)).map((x, i) => (
            <li key={i} className="py-2.5 flex gap-3 items-start">
              <span className={color[x.severity] + ' text-page text-xs rounded px-2 py-0.5 mt-0.5 shrink-0'}>{x.severity}</span>
              <div className="min-w-0">
                <div className="num text-sm text-ink/60 break-all">{x.file}{x.line ? ':' + x.line : ''}</div>
                <div>{x.message}</div>
                <div className="text-sm text-ink/70">Fix: {x.fix}</div>
              </div>
            </li>))}
        </ul>) : <p className="text-ink/70">No issues match this filter.</p>}
      {list.length > 10 && <button onClick={() => setAll(!all)} className="mt-3 text-sm underline">{all ? 'Show fewer' : 'Show all ' + list.length}</button>}
    </div>
  );
}

function Plan({ items }) {
  const [done, setDone] = useState({});
  const [copied, setCopied] = useState('');
  const total = items.reduce((s, p) => s + p.steps.length, 0), got = Object.values(done).filter(Boolean).length;
  const copy = async () => {
    const text = items.map((p, i) => (i + 1) + '. ' + p.title + '\n' + p.steps.map(t => '   [ ] ' + t).join('\n')).join('\n');
    try { await navigator.clipboard.writeText(text); setCopied('Copied'); } catch (e) { setCopied('Copy is blocked here: select the text manually'); }
  };
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="h-2 flex-1 rounded bg-mist" role="progressbar" aria-valuenow={got} aria-valuemax={total}><div className="h-2 rounded bg-teal" style={{ width: (total ? got / total * 100 : 0) + '%' }} /></div>
        <span className="text-sm num">{got} of {total} done</span>
        <button onClick={copy} className="text-sm border border-line rounded-md px-3 py-1 hover:bg-mist">Copy checklist</button>
      </div>
      {copied && <p className="text-sm text-ink/70 mb-3" role="status">{copied}</p>}
      <ol className="space-y-5">
        {items.map((p, i) => (
          <li key={i} className="flex gap-3">
            <span className="font-display text-xl w-6 shrink-0 num">{i + 1}</span>
            <div>
              <h3 className="font-medium">{p.title}</h3>
              <p className="text-ink/70 text-sm mb-1">{p.why}</p>
              {p.steps.map((t, k) => (
                <label key={k} className="flex gap-2 items-start text-sm py-0.5 cursor-pointer">
                  <input type="checkbox" className="mt-1 accent-teal" checked={!!done[i + '-' + k]} onChange={e => setDone({ ...done, [i + '-' + k]: e.target.checked })} />
                  <span className={done[i + '-' + k] ? 'line-through text-ink/50' : ''}>{t}</span>
                </label>))}
            </div>
          </li>))}
      </ol>
    </div>
  );
}

function Upload({ onFiles, onSample, busy }) {
  const [over, setOver] = useState(false);
  const input = useRef();
  return (
    <div onDragOver={e => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
         onDrop={e => { e.preventDefault(); setOver(false); onFiles([...e.dataTransfer.files]); }}
         className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${over ? 'border-teal bg-teal/5' : 'border-line bg-panel'}`}>
      <p className="font-display text-xl">{busy ? 'Analysing…' : 'Drop a project zip, source files, or a predictions CSV'}</p>
      <p className="text-sm text-ink/60 mt-1 mb-4">
        .zip .py .js .jsx .ts .tsx .java .c .cpp .go · a CSV needs <b>actual</b> and <b>predicted</b> columns · files stay in your browser
      </p>
      <input ref={input} type="file" multiple hidden onChange={e => onFiles([...e.target.files])} />
      <button onClick={() => input.current.click()} disabled={busy}
              className="bg-teal text-page px-5 py-2 rounded-md hover:opacity-90 disabled:opacity-50">Choose files</button>
      <button onClick={onSample} disabled={busy} className="ml-3 border border-line px-5 py-2 rounded-md hover:bg-mist disabled:opacity-50">Try sample data</button>
    </div>
  );
}

function Result({ run }) {
  const r = run.result;
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Panel title={r.kind === 'model' ? 'Model score (macro-F1)' : 'Project quality score'}>
        <Score score={r.score} />
        <p className="text-center text-sm text-ink/60 mt-3">{run.filename}</p>
        {r.verdict && <p className="text-center font-medium mt-1" style={{ color: tone(r.score) }}>{r.verdict}</p>}
        {run.delta != null && <p className="text-center text-sm mt-1 num text-ink/70">{run.delta >= 0 ? '+' : ''}{run.delta} since your previous {r.kind === 'model' ? 'model' : 'project'} run</p>}
        {r.kind === 'model' && <p className="text-center text-sm mt-1 num">Accuracy {r.accuracy}% · {r.rows} rows</p>}
      </Panel>
      {r.kind === 'model' ? (<>
        <Panel title="Precision, recall and F1 per class" className="md:col-span-2">
          <Bars labels={r.per_class.map(c => c.label)} data={r.per_class.map(c => Math.round(c.f1 * 100))} label="F1 %" horizontal />
        </Panel>
        <Panel title="Where predictions go wrong" className="md:col-span-3"><Confusion labels={r.labels} matrix={r.confusion} /></Panel>
      </>) : (<>
        <Panel title="Quality dimensions"><Radar dims={r.dimensions} /></Panel>
        <Panel title="Lines of code by language"><Bars labels={Object.keys(r.loc_by_ext)} data={Object.values(r.loc_by_ext)} label="Lines" /></Panel>
        <Panel title="Complexity hotspots" className="md:col-span-3">
          {r.hotspots.length ? (
            <table className="w-full text-sm num"><thead><tr className="text-left text-ink/60"><th>File</th><th>Function</th><th>Complexity</th></tr></thead>
              <tbody>{r.hotspots.map((h, i) => <tr key={i} className="border-t border-line"><td className="py-1">{h.file}</td><td>{h.function}</td><td>{h.complexity}</td></tr>)}</tbody></table>
          ) : <p className="text-ink/60">No function exceeds complexity 10.</p>}
        </Panel>
      </>)}
      <Panel title={'Errors and risks found (' + (r.issues || []).length + ')'} className="md:col-span-3"><Issues items={r.issues || []} /></Panel>
      <Panel title="Key measures to take" className="md:col-span-3">{r.action_plan ? <Plan key={run.id} items={r.action_plan} /> : <Recs items={r.recommendations || []} />}</Panel>
    </div>
  );
}

function History({ runs, onOpen }) {
  const asc = [...runs].reverse();
  const ref = useChart(() => ({
    type: 'line',
    data: { labels: asc.map(r => `#${r.id}`), datasets: [{ data: asc.map(r => r.score), borderColor: cv('teal'), backgroundColor: cv('teal'), tension: .25 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 100 } } }
  }), [runs.length]);
  return (
    <Panel title="Score history">
      <canvas ref={ref} height="90" />
      <table className="w-full text-sm mt-4 num"><tbody>
        {runs.slice(0, 8).map(r => (
          <tr key={r.id} className="border-t border-line cursor-pointer hover:bg-mist" onClick={() => onOpen(r.id)}>
            <td className="py-1.5">#{r.id}</td><td>{r.filename}</td><td>{r.kind}</td>
            <td style={{ color: tone(r.score) }}>{r.score}</td><td className="text-ink/60">{new Date(r.created_at).toLocaleString()}</td>
          </tr>))}
      </tbody></table>
    </Panel>
  );
}

const sampleCsv = () => {
  const L = ['approve', 'review', 'reject'], rows = ['actual,predicted'];
  for (let i = 0; i < 180; i++) {
    const a = i % 9 < 5 ? 0 : i % 9 < 8 ? 1 : 2; let p = a;
    if (a === 1 && i % 3 === 0) p = 0;
    if (a === 2 && i % 2 === 0) p = 1;
    if (a === 0 && i % 11 === 0) p = 1;
    rows.push(L[a] + ',' + L[p]);
  }
  return rows.join('\n');
};

function Step({ title, children }) {
  return (<div className="border-t-2 border-teal pt-3"><h3 className="font-display text-lg mb-1">{title}</h3><p className="text-ink/70">{children}</p></div>);
}

function App() {
  const [run, setRun] = useState(null);
  const [runs, setRuns] = useState(() => { try { return JSON.parse(localStorage.getItem('viz_runs') || '[]'); } catch (e) { return []; } });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [theme, setTheme] = useState(() => { try { return localStorage.getItem('viz_theme') || 'auto'; } catch (e) { return 'auto'; } });
  useEffect(() => {
    const el = document.documentElement;
    if (theme === 'auto') el.removeAttribute('data-theme'); else el.setAttribute('data-theme', theme);
    try { localStorage.setItem('viz_theme', theme); } catch (e) {}
  }, [theme]);
  const cycle = () => setTheme(theme === 'auto' ? 'light' : theme === 'light' ? 'dark' : 'auto');
  const links = [['analyze', 'Analyze'], ['playground', 'Live check'], ['checks', 'What it checks'], ['scoring', 'Scoring'], ['faq', 'FAQ']];
  const save = list => { setRuns(list); try { localStorage.setItem('viz_runs', JSON.stringify(list)); } catch (e) {} };

  const finish = (result, label) => {
    const prevRun = runs.find(r => r.kind === result.kind);
    const entry = { delta: prevRun ? +(result.score - prevRun.score).toFixed(1) : null, id: (runs[0] ? runs[0].id : 0) + 1, filename: label, kind: result.kind, score: result.score, result, created_at: new Date().toISOString() };
    setRun(entry); save([entry, ...runs].slice(0, 30));
  };
  const send = async files => {
    if (!files.length) return;
    setBusy(true); setError('');
    try {
      const bad = files.find(f => !ALLOWED.includes(extOf(f.name)));
      if (bad) throw new Error("'" + (extOf(bad.name) || bad.name) + "' files are not supported.");
      if (files.some(f => f.size > 50 * 1024 * 1024)) throw new Error('Each file must be under 50 MB.');
      if (files.length === 1 && extOf(files[0].name) === '.csv') finish(analyzeModel(await files[0].text()), files[0].name);
      else {
        const code = {}, names = [], extra = {}; let project = false;
        for (const f of files) {
          const e = extOf(f.name);
          if (e === '.zip') { const z = await readZip(f); Object.assign(code, z.files); names.push(...z.names); Object.assign(extra, z.extra); project = true; }
          else if (CODE.includes(e)) { code[f.name] = await f.text(); names.push(f.name); }
        }
        finish(analyzeCode(code, names, extra, project), files[0].name);
      }
    } catch (e) { setError(e.message || 'Could not analyse that file.'); } finally { setBusy(false); }
  };
  const sample = () => { setError(''); finish(analyzeModel(sampleCsv()), 'sample-predictions.csv'); location.hash = 'analyze'; };

  return (
    <div>
      <header className="sticky z-20 bg-panel border-b border-line" style={{ top: 'env(safe-area-inset-top, 0px)' }}>
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
          <a href="#top" className="font-display text-lg shrink-0">Accuracy Visualizer</a>
          <nav className="flex gap-5 text-sm overflow-x-auto">{links.map(([id, t]) => <a key={id} href={'#' + id} className="hover:underline whitespace-nowrap">{t}</a>)}</nav>
          <button onClick={cycle} aria-label="Change colour theme" className="text-sm border border-line rounded-md px-3 py-1 hover:bg-mist shrink-0">Theme: {theme}</button>
        </div>
      </header>
      <main id="top" className="max-w-6xl mx-auto px-4">
        <section className="py-14 md:py-20 max-w-3xl">
          <h1 className="font-display text-4xl md:text-6xl leading-tight">Find out where your project loses points</h1>
          <p className="text-lg text-ink/70 mt-5 max-w-xl">Upload a predictions CSV or a project zip. It finds errors inside, scores accuracy and project health, and tells you the key measures to take, in priority order.</p>
          <div className="flex flex-wrap gap-3 mt-7">
            <a href="#analyze" className="bg-teal text-page px-5 py-2.5 rounded-md hover:opacity-90">Analyze a file</a>
            <button onClick={sample} className="border border-line px-5 py-2.5 rounded-md hover:bg-mist">Try sample data</button>
            <a href="#playground" className="border border-line px-5 py-2.5 rounded-md hover:bg-mist">Paste code instead</a>
          </div>
        </section>
        <Section id="analyze" title="Analyze your project" intro="Drop a zip, source files or a predictions CSV. Results appear below, with a history of your last runs.">
          <div className="space-y-5">
            <Upload onFiles={send} onSample={sample} busy={busy} />
            {error && <div role="alert" className="bg-bad/10 border border-bad text-bad rounded-md px-4 py-2">{error}</div>}
            {run && <Result key={run.id + theme} run={run} />}
            {runs.length > 0 && <History key={theme} runs={runs} onOpen={id => setRun(runs.find(r => r.id === id))} />}
            {runs.length > 0 && <button onClick={() => { save([]); setRun(null); }} className="text-sm border border-line rounded-md px-3 py-1.5 hover:bg-mist">Clear history</button>}
          </div>
        </Section>
        <Section id="playground" title="Check a snippet live" intro="No file needed. Edit the example or paste your own code and the issues update as you type.">
          <Playground />
        </Section>
        <Section id="checks" title="What it checks" intro="Pick a category to see what is looked for and an example of what gets flagged.">
          <Checks />
        </Section>
        <Section id="scoring" title="How the score works" intro="Move the sliders to see how each area moves the overall score, and where the easiest gains are.">
          <ScoreLab />
        </Section>
        <Section id="how-it-works" title="How it works">
          <div className="grid gap-6 md:grid-cols-3">
            <Step title="Predictions CSV">Include columns named actual and predicted. Bad rows and label mismatches are flagged, and you get accuracy, precision, recall and F1 for each class, plus a confusion matrix that shows which classes get mixed up.</Step>
            <Step title="Project zip or source files">Python, JavaScript, TypeScript, Java, C, C++ and Go are checked for syntax errors, risky patterns and exposed secrets, then scored on tests, complexity, documentation, security and project setup.</Step>
            <Step title="Your files stay put">Analysis runs in your browser. Nothing is uploaded to a server, and your history stays in this browser until you clear it.</Step>
          </div>
        </Section>
        <Section id="faq" title="Questions">
          <Faq />
        </Section>
      </main>
      <footer className="border-t border-line">
        <p className="max-w-6xl mx-auto px-4 py-6 text-sm text-ink/60">Scores are estimates from static analysis. They don’t run your code or tests, so use them to decide where to look first.</p>
      </footer>
    </div>
  );
}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
