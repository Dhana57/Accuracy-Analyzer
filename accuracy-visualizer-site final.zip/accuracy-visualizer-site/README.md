# Accuracy Visualizer

A browser-only website. No server, no database, no install.

## Run it
1. Unzip the folder.
2. Double-click `index.html` (opens in Chrome, Edge, Firefox or Safari). You need internet, because React, Tailwind, Chart.js and JSZip load from CDNs.
3. Click "Try sample data" to see a full result.
4. Drag in your own project .zip, source files, or a CSV with `actual` and `predicted` columns.

## Optional: run on a local web address
    python -m http.server 8000
then open http://localhost:8000 (run it inside this folder).

## Edit the code (optional)
`source/app.jsx` is the readable source. After changes, compile and inline it:
    npx -p typescript tsc source/app.jsx --allowJs --jsx react --target ES2019 --lib ES2019,DOM --skipLibCheck --outDir out
Then paste `out/app.js` into `source/shell.html` where `__APP__` is, and save the result as `index.html`.
